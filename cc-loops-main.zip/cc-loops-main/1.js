// Write your code below
let vacationSpots = ["Orlando, Florida", "Hanapepe, Hawaii", "Anaheim, California"]
console.log(vacationSpots[0]);
console.log(vacationSpots[1]);
console.log(vacationSpots[2]);