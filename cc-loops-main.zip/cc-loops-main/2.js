// Write your code below

for (let num = 5; num < 11; num++) {
    console.log(num);
  }