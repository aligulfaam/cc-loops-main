const vacationSpots = ['Bali', 'Paris', 'Tulum'];
// Write your code below
for (let i=0; i<vacationSpots.length; i++) {
  console.log("I would love to visit " + vacationSpots[i]);
}

